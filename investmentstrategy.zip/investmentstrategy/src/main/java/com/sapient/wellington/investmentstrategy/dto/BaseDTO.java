package com.sapient.wellington.investmentstrategy.dto;

import java.io.Serializable;

/**
 * A generic dto object
 *
 *
 */
public class BaseDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2664876738254485142L;

}
