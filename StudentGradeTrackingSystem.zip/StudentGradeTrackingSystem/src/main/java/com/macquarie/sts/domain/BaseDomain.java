package main.java.com.macquarie.sts.domain;
/**
 * A generic domain object
 *
 *
 */
public class BaseDomain {

	private String domainID;

	public String getDomainID() {
		return domainID;
	}

	public void setDomainID(String domainID) {
		this.domainID = domainID;
	}

}
