package main.java.com.macquarie.sts.dao;

/**
 * A DAO interface for operation with student informations
 * 
 *
 */
public interface StudentDao extends BaseDao {

}
