package main.java.com.macquarie.sts.dao;

/**
 * A DAO interface for operation with teachers informations
 * 
 *
 */
public interface TeacherDao extends BaseDao {

}
