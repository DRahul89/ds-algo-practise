package main.java.com.macquarie.sts.constant;

/**
 * constants specific to application
 * 
 *
 */
public interface ApplicationConstants {
	
	public static final Integer HUNDRED = 100;

}
